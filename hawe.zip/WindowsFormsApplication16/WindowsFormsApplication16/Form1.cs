﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication16
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connect_info = "DATA SOURCE = xe; User Id = scott; Password = tiger";
            OracleConnection conn = new OracleConnection(connect_info);
            conn.Open();

            DataSet ds = new DataSet();
            string SQL = "SELECT * FROM phonebook7 order by no";

            OracleCommand oc1 = new OracleCommand(SQL, conn);
            OracleDataReader reader = oc1.ExecuteReader();

            StringBuilder sb = new StringBuilder();
            while (reader.Read())
            {
                //Console.WriteLine(reader.GetInt32(0) + " : " + reader.GetString(1) + " ");
                int no = reader.GetInt32(0);
                string name = reader.GetString(1);
                string pnumber = reader.GetString(2);
                sb.Append(
                    no + " \t\t\t\t\t " + name + "\t\t\t\t\t" + pnumber + "\n");
            }

            richTextBox1.Text = "번호" + "\t\t\t\t\t" + "이름" + "\t\t\t\t\t" + "번호" + "\n\n" + sb.ToString();
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connect_info = "DATA SOURCE = xe; User Id = scott; Password = tiger";
            OracleConnection conn = new OracleConnection(connect_info);
            conn.Open();

            DataSet ds = new DataSet();
            string SQL = "insert into phonebook7 (no, name, pnumber) values (" + textBox1.Text + ", '" + textBox2.Text + "', '" + textBox3.Text + "')";

            OracleCommand oc1 = new OracleCommand(SQL, conn);
            oc1.ExecuteNonQuery();

            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connect_info = "DATA SOURCE = xe; User Id = scott; Password = tiger";
            OracleConnection conn = new OracleConnection(connect_info);
            conn.Open();

            DataSet ds = new DataSet();
            string SQL = "delete from phonebook7 where name = '" + textBox4.Text + "'";

            OracleCommand oc1 = new OracleCommand(SQL, conn);
            oc1.ExecuteNonQuery();

            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string connect_info = "DATA SOURCE = xe; User Id = scott; Password = tiger";
            OracleConnection conn = new OracleConnection(connect_info);
            conn.Open();

            DataSet ds = new DataSet();
            string SQL = "update phonebook7 set no = " + textBox6.Text + ", name = '" + textBox7.Text + "', pnumber = '" + textBox8.Text + "' where name = '" + textBox5.Text + "'";

            OracleCommand oc1 = new OracleCommand(SQL, conn);
            oc1.ExecuteNonQuery();

            conn.Close();
        }
    }
}
